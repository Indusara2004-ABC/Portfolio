// Scroll reveal animation
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("show");
    }
  });
});

document.querySelectorAll(".hidden").forEach(el => observer.observe(el));

// Smooth scroll
function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({
    behavior: "smooth"
  });
}

// Mobile menu
function toggleMenu() {
  document.getElementById("nav-links").classList.toggle("active");
}

// Contact form
document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  document.getElementById("msg").innerText = "Message sent successfully!";
});


const btn = document.getElementById("goUpBtn");

// show/hide on scroll
window.addEventListener("scroll", () => {
  if (window.scrollY > 200) {
    btn.style.display = "flex";
  } else {
    btn.style.display = "none";
  }
});

// smooth scroll to top
btn.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

let btnClick1 = document.getElementById("btn-1");

btnClick1.addEventListener("click", () => {
  window.location.href = "https://github.com/Indusara2004-ABC/Ceylon-Trails.git";
});


let btnClick2 = document.getElementById("btn-2");

btnClick2.addEventListener("click", () => {
  window.location.href = "https://github.com/Indusara2004-ABC/Login-Interface.git";
});


let btnClick3 = document.getElementById("btn-3");

btnClick3.addEventListener("click", () => {
  window.location.href = "";
});

